using Dapper;
using Microsoft.Data.Sqlite;
using PrestamosDeLibros.Models;

namespace PrestamosDeLibros.Services;

public class EstudianteService(IConfiguration configuration)
{
    private readonly string _connectionString = configuration.GetConnectionString("DefaultConnection")!;

    public async Task InitializeAsync()
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = @"
            CREATE TABLE IF NOT EXISTS Estudiantes (
                EstudianteId INTEGER PRIMARY KEY AUTOINCREMENT,
                Matricula TEXT NOT NULL,
                Nombres TEXT NOT NULL,
                Telefono TEXT,
                Email TEXT,
                Direccion TEXT
            );";
        await connection.ExecuteAsync(sql);
    }

    public async Task<int> SaveAsync(EstudianteRecord record)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = @"
            INSERT INTO Estudiantes (Matricula, Nombres, Telefono, Email, Direccion) 
            VALUES (@Matricula, @Nombres, @Telefono, @Email, @Direccion); 
            SELECT last_insert_rowid();";
        return await connection.ExecuteScalarAsync<int>(sql, record);
    }

    public async Task<int> UpdateAsync(EstudianteRecord record)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = @"
            UPDATE Estudiantes 
            SET Matricula = @Matricula, 
                Nombres = @Nombres, 
                Telefono = @Telefono, 
                Email = @Email, 
                Direccion = @Direccion 
            WHERE EstudianteId = @EstudianteId;";
        return await connection.ExecuteAsync(sql, record);
    }

    public async Task<EstudianteRecord?> GetByIdAsync(int id)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = "SELECT * FROM Estudiantes WHERE EstudianteId = @Id;";
        return await connection.QuerySingleOrDefaultAsync<EstudianteRecord>(sql, new { Id = id });
    }

    public async Task<IEnumerable<EstudianteRecord>> GetListAsync()
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = "SELECT * FROM Estudiantes ORDER BY Nombres ASC;";
        return await connection.QueryAsync<EstudianteRecord>(sql);
    }
    
    public async Task<int> DeleteAsync(int id)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = "DELETE FROM Estudiantes WHERE EstudianteId = @Id;";
        return await connection.ExecuteAsync(sql, new { Id = id });
    }
}