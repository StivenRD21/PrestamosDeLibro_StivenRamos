using Dapper;
using Microsoft.Data.Sqlite;
using PrestamosDeLibros.Models;

namespace PrestamosDeLibros.Services;

public class LibroService(IConfiguration configuration)
{
    private readonly string _connectionString = configuration.GetConnectionString("DefaultConnection")!;

    public async Task InitializeAsync()
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = @"
            CREATE TABLE IF NOT EXISTS Libros (
                LibroId INTEGER PRIMARY KEY AUTOINCREMENT,
                Titulo TEXT NOT NULL,
                Autor TEXT NOT NULL,
                Editorial TEXT,
                AnioPublicacion INTEGER NOT NULL,
                CantidadDisponible INTEGER NOT NULL
            );";
        await connection.ExecuteAsync(sql);
    }

    public async Task<int> SaveAsync(LibroRecord record)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = @"
            INSERT INTO Libros (Titulo, Autor, Editorial, AnioPublicacion, CantidadDisponible) 
            VALUES (@Titulo, @Autor, @Editorial, @AnioPublicacion, @CantidadDisponible); 
            SELECT last_insert_rowid();";
        return await connection.ExecuteScalarAsync<int>(sql, record);
    }

    public async Task<int> UpdateAsync(LibroRecord record)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = @"
            UPDATE Libros 
            SET Titulo = @Titulo, 
                Autor = @Autor, 
                Editorial = @Editorial, 
                AnioPublicacion = @AnioPublicacion, 
                CantidadDisponible = @CantidadDisponible 
            WHERE LibroId = @LibroId;";
        return await connection.ExecuteAsync(sql, record);
    }

    public async Task<LibroRecord?> GetByIdAsync(int id)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = "SELECT * FROM Libros WHERE LibroId = @Id;";
        return await connection.QuerySingleOrDefaultAsync<LibroRecord>(sql, new { Id = id });
    }

    public async Task<IEnumerable<LibroRecord>> GetListAsync()
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = "SELECT * FROM Libros ORDER BY Titulo ASC;";
        return await connection.QueryAsync<LibroRecord>(sql);
    }

    public async Task<int> DeleteAsync(int id)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = "DELETE FROM Libros WHERE LibroId = @Id;";
        return await connection.ExecuteAsync(sql, new { Id = id });
    }
}