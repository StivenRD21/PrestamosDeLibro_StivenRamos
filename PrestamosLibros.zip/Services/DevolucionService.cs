using Dapper;
using Microsoft.Data.Sqlite;
using PrestamosDeLibros.Models;

namespace PrestamosDeLibros.Services;

public class DevolucionService(IConfiguration configuration)
{
    private readonly string _connectionString = configuration.GetConnectionString("DefaultConnection")!;

    public async Task InitializeAsync()
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = @"
            CREATE TABLE IF NOT EXISTS Devoluciones (
                DevolucionId INTEGER PRIMARY KEY AUTOINCREMENT,
                PrestamoId INTEGER NOT NULL,
                FechaDevolucionReal TEXT NOT NULL,
                Observaciones TEXT
            );";
        await connection.ExecuteAsync(sql);
    }

    public async Task<int> SaveAsync(DevolucionRecord record)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = @"
            INSERT INTO Devoluciones (PrestamoId, FechaDevolucionReal, Observaciones) 
            VALUES (@PrestamoId, @FechaDevolucionReal, @Observaciones); 
            SELECT last_insert_rowid();";
        return await connection.ExecuteScalarAsync<int>(sql, record);
    }

    public async Task<int> UpdateAsync(DevolucionRecord record)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = @"
            UPDATE Devoluciones 
            SET PrestamoId = @PrestamoId, 
                FechaDevolucionReal = @FechaDevolucionReal, 
                Observaciones = @Observaciones 
            WHERE DevolucionId = @DevolucionId;";
        return await connection.ExecuteAsync(sql, record);
    }

    public async Task<DevolucionRecord?> GetByIdAsync(int id)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = "SELECT * FROM Devoluciones WHERE DevolucionId = @Id;";
        return await connection.QuerySingleOrDefaultAsync<DevolucionRecord>(sql, new { Id = id });
    }

    public async Task<IEnumerable<DevolucionRecord>> GetListAsync()
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = "SELECT * FROM Devoluciones ORDER BY FechaDevolucionReal DESC;";
        return await connection.QueryAsync<DevolucionRecord>(sql);
    }

    public async Task<int> DeleteAsync(int id)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = "DELETE FROM Devoluciones WHERE DevolucionId = @Id;";
        return await connection.ExecuteAsync(sql, new { Id = id });
    }
}