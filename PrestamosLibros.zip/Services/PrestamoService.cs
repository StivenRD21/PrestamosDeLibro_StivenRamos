using Dapper;
using Microsoft.Data.Sqlite;
using PrestamosDeLibros.Models;

namespace PrestamosDeLibros.Services;

public class PrestamoService(IConfiguration configuration)
{
    private readonly string _connectionString = configuration.GetConnectionString("DefaultConnection")!;

    public async Task InitializeAsync()
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = @"
            CREATE TABLE IF NOT EXISTS Prestamos (
                PrestamoId INTEGER PRIMARY KEY AUTOINCREMENT,
                EstudianteId INTEGER NOT NULL,
                LibroId INTEGER NOT NULL,
                FechaPrestamo TEXT NOT NULL,
                FechaDevolucionEsperada TEXT NOT NULL,
                Estado TEXT NOT NULL
            );";
        await connection.ExecuteAsync(sql);
    }

    public async Task<int> SaveAsync(PrestamoRecord record)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = @"
            INSERT INTO Prestamos (EstudianteId, LibroId, FechaPrestamo, FechaDevolucionEsperada, Estado) 
            VALUES (@EstudianteId, @LibroId, @FechaPrestamo, @FechaDevolucionEsperada, @Estado); 
            SELECT last_insert_rowid();";
        return await connection.ExecuteScalarAsync<int>(sql, record);
    }

    public async Task<int> UpdateAsync(PrestamoRecord record)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = @"
            UPDATE Prestamos 
            SET EstudianteId = @EstudianteId, 
                LibroId = @LibroId, 
                FechaPrestamo = @FechaPrestamo, 
                FechaDevolucionEsperada = @FechaDevolucionEsperada, 
                Estado = @Estado 
            WHERE PrestamoId = @PrestamoId;";
        return await connection.ExecuteAsync(sql, record);
    }

    public async Task<PrestamoRecord?> GetByIdAsync(int id)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = "SELECT * FROM Prestamos WHERE PrestamoId = @Id;";
        return await connection.QuerySingleOrDefaultAsync<PrestamoRecord>(sql, new { Id = id });
    }

    public async Task<IEnumerable<PrestamoRecord>> GetListAsync()
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = "SELECT * FROM Prestamos ORDER BY FechaPrestamo DESC;";
        return await connection.QueryAsync<PrestamoRecord>(sql);
    }

    public async Task<int> DeleteAsync(int id)
    {
        using var connection = new SqliteConnection(_connectionString);
        var sql = "DELETE FROM Prestamos WHERE PrestamoId = @Id;";
        return await connection.ExecuteAsync(sql, new { Id = id });
    }
}