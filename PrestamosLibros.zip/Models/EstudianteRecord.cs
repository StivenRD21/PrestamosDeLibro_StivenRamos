namespace PrestamosDeLibros.Models;

public record EstudianteRecord
{
    public int EstudianteId { get; init; }
    public string Matricula { get; init; } = string.Empty;
    public string Nombres { get; init; } = string.Empty;
    public string Telefono { get; init; } = string.Empty;
    public string Email { get; init; } = string.Empty;
    public string Direccion { get; init; } = string.Empty;
}