namespace PrestamosDeLibros.Models;

public record DevolucionRecord
{
    public int DevolucionId { get; init; }
    public int PrestamoId { get; init; }
    public DateTime FechaDevolucionReal { get; init; }
    public string Observaciones { get; init; } = string.Empty;
}