namespace PrestamosDeLibros.Models;

public record LibroRecord
{
    public int LibroId { get; init; }
    public string Titulo { get; init; } = string.Empty;
    public string Autor { get; init; } = string.Empty;
    public string Editorial { get; init; } = string.Empty;
    public int AnioPublicacion { get; init; }
    public int CantidadDisponible { get; init; }
}