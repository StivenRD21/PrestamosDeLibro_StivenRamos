namespace PrestamosDeLibros.Models;

public record PrestamoRecord
{
    public int PrestamoId { get; init; }
    public int EstudianteId { get; init; }
    public int LibroId { get; init; }
    public DateTime FechaPrestamo { get; init; }
    public DateTime FechaDevolucionEsperada { get; init; }
    public string Estado { get; init; } = string.Empty;
}